Credit to ZKB for making the Golden Theo sprites.
He is an amazing person for making sumber and then NCG reacted with reckoning one of my favorite maps.
Go play ZKB's 99 Traps. It's amazing and goes from easy to pretty hard. If you like suffering play reckoning.